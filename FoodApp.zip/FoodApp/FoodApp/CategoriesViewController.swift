//
//  CategoriesViewController.swift
//  FoodApp
//
//  Created by BridgeLabz on 06/07/18.
//  Copyright © 2018 BridgeLabz. All rights reserved.
//

import UIKit

class CategoriesViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

   
}
