//
//  ProfileViewController.swift
//  FundooNotes
//
//  Created by BridgeLabz on 30/04/18.
//  Copyright © 2018 BridgeLabz. All rights reserved.
//

import UIKit

class ProfileViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }

    

}
