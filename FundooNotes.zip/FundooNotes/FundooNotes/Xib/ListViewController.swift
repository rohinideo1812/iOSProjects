//
//  ListViewController.swift
//  FundooNotes
//
//  Created by BridgeLabz on 12/05/18.
//  Copyright © 2018 BridgeLabz. All rights reserved.
//

import UIKit

class ListViewController: UIViewController {
//    var colorArray =  [UIColor.blue,UIColor.green]
//    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
//        return colorArray.count
//    }
//
//    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
//        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)
//        cell.contentView.backgroundColor = colorArray[indexPath.row]
//        return cell
//    }
//

    @IBAction func chooseImageButtonPress(_ sender: UIButton) {
       
    }
    @IBOutlet weak var colorSelectionCV: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()

//        colorSelectionCV.register(UICollectionViewCell.self, forCellWithReuseIdentifier: "cell")
//        colorSelectionCV.delegate = self
//        colorSelectionCV.dataSource = self

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
  

}
