//
//  NoteAddViewController.swift
//  FundooNotes
//
//  Created by BridgeLabz on 18/05/18.
//  Copyright © 2018 BridgeLabz. All rights reserved.
//

import UIKit

class NoteAddViewController: UIViewController,UITextViewDelegate{
    
    //Mark: IBOutlet
    @IBOutlet weak var heightConstraintOfImageView: NSLayoutConstraint!
    @IBOutlet weak var heightConstraintOfTextField: NSLayoutConstraint!
    @IBOutlet weak var heightConstraintOfTextView: NSLayoutConstraint!
    @IBOutlet weak var addImageInNote: UIImageView!
    @IBOutlet weak var noteTextField: UITextField!
    @IBOutlet weak var noteTextView: UITextView!

    
    override func viewDidLoad() {
        super.viewDidLoad()
        noteTextView.delegate = self
    }
    
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        if (text == "\n")
        {
            textView.resignFirstResponder()
            return false
        }
        return true
    }
    
    
    func textViewDidBeginEditing(_ textView : UITextView){
        if textView.text == "Note" {
            textView.text = ""
        }
        textView.becomeFirstResponder()
    }
    
    
    func textViewDidEndEditing(_ textView : UITextView){
        if textView.text == "" {
            textView.text = "Note"
        }
        textView.resignFirstResponder()
        }
}
