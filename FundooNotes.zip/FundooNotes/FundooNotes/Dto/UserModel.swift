//
//  UserModel.swift
//  FundooNotes
//
//  Created by BridgeLabz on 25/04/18.
//  Copyright © 2018 BridgeLabz. All rights reserved.
//

import Foundation
struct UserModel {
    
    let firstName : String?
    let lastName : String?
    let email : String?
    let password : String?
}
