//
//  NoteAdditionViewController.swift
//  FundooNotes
//
//  Created by BridgeLabz on 21/05/18.
//  Copyright © 2018 BridgeLabz. All rights reserved.
//

import UIKit
import XLActionController

class NoteAdditionViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    
    //Mark: IBOutlet
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var heightConstraintOfView: NSLayoutConstraint!
    @IBOutlet weak var addNoteBottomView: AddNoteBottomView!
    
    
    //Mark: Properties
    var heightConstraintOfImageView: NSLayoutConstraint!
    let imagePicker = UIImagePickerController()
    var isBottonMenuVisible = true
    var note : NoteModel?
    var ispin = false
    var noteAddView : NoteAddUIView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        imagePicker.delegate = self
        configureNavigationBar()
        noteAddView = NoteAddUIView(frame: CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: 320))
        noteAddView.titleTextView.delegate = self
        noteAddView.titleTextView.tag = 1
        noteAddView.noteTextView.delegate = self
        noteAddView.noteTextView.tag = 2
        addNoteBottomView.leftBottomMenuButton.addTarget(self, action: #selector(leftBottomButtonPress), for: .touchUpInside)
    }

    //MARK: NavigationBar buttons
    func configureNavigationBar(){
        
        let backBarButton = UIBarButtonItem(image : UIImage(named: "ic_keyboard_backspace"),landscapeImagePhone: nil, style: .done, target: self, action: #selector(backBarButtonPress))
        self.navigationItem.leftBarButtonItem = backBarButton
        let pinBarButton = UIBarButtonItem(image: UIImage(named: "ic_fiber_pin"), landscapeImagePhone: nil, style: .done, target: self, action: #selector(pinBarButtonPress))
        let reminderBarButton = UIBarButtonItem(image: UIImage(named: "ic_touch_app"), landscapeImagePhone: nil, style: .done, target: self, action: #selector(reminderBarButtonPress))
        let archiveBarButton = UIBarButtonItem(image: UIImage(named: "ic_archive"), landscapeImagePhone: nil, style: .done, target: self, action: #selector(archiveBarButtonPress))
        self.navigationItem.rightBarButtonItems = [archiveBarButton,reminderBarButton,pinBarButton]
         navigationController?.navigationBar.barTintColor = UIColor.white
    }
    
    @objc func backBarButtonPress(){
    if noteAddView.titleTextView.text == nil && noteAddView.noteTextView.text == nil && noteAddView.imageView.image == nil {
    let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
    let newViewController = storyBoard.instantiateViewController(withIdentifier: "DashBoardViewController") as! DashBoardViewController
  self.navigationController?.pushViewController(newViewController, animated: true)

    }else {
        note = NoteModel(title: noteAddView.titleTextView.text, note: noteAddView.noteTextView.text,image: noteAddView.imageView.image)
            UserDataBase.sharedInstance.insertNoteData(object: note)
        
                }
    }
    
    //Mark: Action on Bottom Left Button Press
    @objc func leftBottomButtonPress() {
        
        let actionController = YoutubeActionController()
        
        actionController.addAction(Action(ActionData(title: "Take photo", image: UIImage(named: "ic_camera_alt")!), style: .default, handler: { action in
        }))
        actionController.addAction(Action(ActionData(title: "Choose image", image: UIImage(named: "ic_choose_image")!), style: .default, handler: { action in
            self.imagePicker.allowsEditing = false
            self.imagePicker.sourceType = .photoLibrary
            self.present(self.imagePicker, animated: true, completion: nil)
        }))
        actionController.addAction(Action(ActionData(title: "Drawing", image: UIImage(named: "ic_border_color")!), style: .default, handler: { action in
        }))
        actionController.addAction(Action(ActionData(title: "Recording", image: UIImage(named: "ic_settings_voice")!), style: .cancel, handler: nil))
        
        actionController.addAction(Action(ActionData(title: "Tick boxes", image: UIImage(named: "ic_view_list")!), style: .cancel, handler: nil))
        present(actionController, animated: true, completion: nil)
    }
    
    //Mark: Action on pinBarButtonPress
    @objc func pinBarButtonPress(){
        
        print("Tapped with Pin Button")
    }
    
    //Mark: Action on archiveBarButtonPress
    @objc func archiveBarButtonPress(){
        print("Tapped with Archive Button")
    }
    
    //Mark: Action on reminderBarButtonPress
    @objc func reminderBarButtonPress() {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let newViewController = storyBoard.instantiateViewController(withIdentifier: "ReminderViewController") as! ReminderViewController
        self.navigationController?.pushViewController(newViewController, animated: true)
    }

    //Mark: Image picker Controller
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if let pickedImage = info[UIImagePickerControllerOriginalImage] as? UIImage {
            let newImage = Helper.shared.getScaledImage(image: pickedImage, width: view.frame.size.width)
            self.noteAddView.imageView.contentMode = .scaleAspectFit
            self.noteAddView.imageView.image = newImage
            updateView()
        }
        dismiss(animated: true, completion: nil)
    }
}

    //Mark: TextView Delegates
    extension NoteAdditionViewController:UITextViewDelegate {
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        let font = UIFont.systemFont(ofSize: 14)
        let height = heightForView(text: self.noteAddView.noteTextView.text, font: font, width: self.noteAddView.noteTextView.frame.size.width)
        self.noteAddView.heightConstraintOfNoteTextView.constant = height
        updateView()
        return true
    }
    
    func textViewDidBeginEditing(_ textView : UITextView){
        setPlaceholderText(textview: textView)
    }
    
    func textViewDidEndEditing(_ textView : UITextView){
        setPlaceholderText(textview: textView)

    }
    
        
    func textViewDidChange(_ textView: UITextView) {
        if textView.tag == 1{
            setTextViewSize(textview: textView)
        }else if textView.tag == 2{
            setTextViewSize(textview: textView)
        }
       
    }
 
    //Mark: Get height of View
    func heightForView(text:String?, font:UIFont, width:CGFloat) -> CGFloat {
        let label:UILabel = UILabel(frame: CGRect(x: 0, y: 0, width: width, height: CGFloat.greatestFiniteMagnitude))
        label.numberOfLines = 0
        label.lineBreakMode = NSLineBreakMode.byWordWrapping
        label.font = font
        label.text = text
        label.sizeToFit()
        if label.frame.height < 40 {
            return 40
        }else{
            return label.frame.height
        }
    }
    
    //Mark: View Update
    func updateView(){
        
        if let image = self.noteAddView.imageView.image{
            self.noteAddView.heightConstraintOfImageView.constant = image.size.height
        }else{
            self.noteAddView.heightConstraintOfImageView.constant = 0
        }
        
        let height = self.noteAddView.heightConstraintOfImageView.constant + 32 + self.noteAddView.heightConstraintOftitleTextView.constant + self.noteAddView.heightConstraintOfNoteTextView.constant
        self.noteAddView.contentView.frame.size.height = height
        self.contentView.frame.size.height = height
        
    }
   
    //Mark: Set PlaceHolder to TextView
    func setPlaceholderText(textview : UITextView){
            if textview.tag == 1{
                if textview.text == "" {
                    textview.text = "Note"
                }else if textview.text == "Note"{
                    textview.text = ""
                }
            } else if textview.tag == 2{
                if textview.text == ""{
                    textview.text = "Title"
                }else if textview.text == "Title"{
                    textview.text = ""
                }
            }
}
        
        func setTextViewSize(textview : UITextView){
            if textview.contentSize.height > textview.frame.size.height {
                
                let fixedWidth = textview.frame.size.width
                textview.sizeThatFits(CGSize(width: fixedWidth, height: CGFloat.greatestFiniteMagnitude))
                
                var newFrame = textview.frame
                let newSize = textview.sizeThatFits(CGSize(width: fixedWidth, height: CGFloat.greatestFiniteMagnitude))
                
                newFrame.size = CGSize(width: max(newSize.width, fixedWidth), height: newSize.height)
                
                textview.frame = newFrame;
            }
        }
}
