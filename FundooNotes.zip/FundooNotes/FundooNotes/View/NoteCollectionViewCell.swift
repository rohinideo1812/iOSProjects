//
//  NoteCollectionViewCell.swift
//  FundooNotes
//
//  Created by BridgeLabz on 14/05/18.
//  Copyright © 2018 BridgeLabz. All rights reserved.
//

import UIKit

class NoteCollectionViewCell: UICollectionViewCell {
    
    //MARK: IBOutlet
    @IBOutlet weak var noteViewImage: UIImageView!
    @IBOutlet weak var noteLabel: UILabel!
}
