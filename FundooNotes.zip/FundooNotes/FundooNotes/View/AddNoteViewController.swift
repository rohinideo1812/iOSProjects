//
//  AddNoteViewController.swift
//  FundooNotes
//
//  Created by BridgeLabz on 05/05/18.
//  Copyright © 2018 BridgeLabz. All rights reserved.
//

import UIKit
import XLActionController


class AddNoteViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate{
    
    //MARK: IBOutlet
    @IBOutlet weak var tableView: UITableView!
    
    //MARK: Properties
    var heightConstraintOfImageView: NSLayoutConstraint!
    let imagePicker = UIImagePickerController()
    var isBottonMenuVisible = true
    var note : NoteModel?
    var ispin = false
    var noteAddView : NoteAddUIView!
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
//        imagePicker.delegate = self
//        configureNavigationBar()
//        self.noteAddView = NoteAddUIView(frame: CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: 84))
//        tableView.tableHeaderView = noteAddView
//        self.noteAddView.titleTextField.delegate = self
//        self.noteAddView.noteTextView.delegate = self

    }
    
    //MARK: NavigationBar buttons
    func configureNavigationBar(){
        
        let backBarButton = UIBarButtonItem(image : UIImage(named: "ic_keyboard_backspace"),landscapeImagePhone: nil, style: .done, target: self, action: #selector(backBarButtonPress))
        self.navigationItem.leftBarButtonItem = backBarButton
        let pinBarButton = UIBarButtonItem(image: UIImage(named: "ic_fiber_pin"), landscapeImagePhone: nil, style: .done, target: self, action: #selector(pinBarButtonPress))
        let reminderBarButton = UIBarButtonItem(image: UIImage(named: "ic_touch_app"), landscapeImagePhone: nil, style: .done, target: self, action: #selector(reminderBarButtonPress))
        let archiveBarButton = UIBarButtonItem(image: UIImage(named: "ic_archive"), landscapeImagePhone: nil, style: .done, target: self, action: #selector(archiveBarButtonPress))
        
        self.navigationItem.rightBarButtonItems = [pinBarButton,reminderBarButton,archiveBarButton]
    }
    
    //Mark: Action on Bottom Left Button Press
    @IBAction func leftBottomButtonPress(_ sender: UIButton) {
        
        let actionController = YoutubeActionController()
        
        actionController.addAction(Action(ActionData(title: "Take photo", image: UIImage(named: "ic_camera_alt")!), style: .default, handler: { action in
        }))
        actionController.addAction(Action(ActionData(title: "Choose image", image: UIImage(named: "ic_choose_image")!), style: .default, handler: { action in
            self.imagePicker.allowsEditing = false
            self.imagePicker.sourceType = .photoLibrary
            self.present(self.imagePicker, animated: true, completion: nil)
        }))
        actionController.addAction(Action(ActionData(title: "Drawing", image: UIImage(named: "ic_border_color")!), style: .default, handler: { action in
        }))
        actionController.addAction(Action(ActionData(title: "Recording", image: UIImage(named: "ic_settings_voice")!), style: .cancel, handler: nil))
        
        actionController.addAction(Action(ActionData(title: "Tick boxes", image: UIImage(named: "ic_view_list")!), style: .cancel, handler: nil))
        present(actionController, animated: true, completion: nil)
    }
    
    //Mark: Action on pinBarButtonPress
    @objc func pinBarButtonPress(){
        print("Tapped with Pin Button")
    }
    
    //Mark: Action on archiveBarButtonPress
    @objc func archiveBarButtonPress(){
        print("Tapped with Archive Button")
    }
    
    //Mark: Action on reminderBarButtonPress
    @objc func reminderBarButtonPress(){
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let newViewController = storyBoard.instantiateViewController(withIdentifier: "ReminderViewController") as!  ReminderViewController
        self.present(newViewController, animated: true, completion: nil)
    }
  
    //Mark: Action on backBarButtonPress
    @objc func backBarButtonPress(){
//        if titleTextField.text == nil && noteTextField.text == nil {
//            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
//            let newViewController = storyBoard.instantiateViewController(withIdentifier: "NoteViewController") as! NoteViewController
//            self.present(newViewController, animated: true, completion: nil)
//
//        }else {
//            note = NoteModel(title: noteTextField.text, note: titleTextField.text)
//            UserDataBase.sharedInstance.insertNoteData(object: note)
//
//        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
//        if textField == noteAddView.noteTextField{
//           noteAddView.noteTextField.resignFirstResponder()
//
//        }else{
//            noteAddView.titleTextField.resignFirstResponder()
//        }
        return true
    }
    
    //Mark: Image picker Controller
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if let pickedImage = info[UIImagePickerControllerOriginalImage] as? UIImage {
            let newImage = getScaledImage(image: pickedImage, width: view.frame.size.width)
            self.noteAddView.imageView.contentMode = .scaleAspectFit
            self.noteAddView.imageView.image = newImage
            updateView()
        }
        dismiss(animated: true, completion: nil)
    }
    
    //Mark: Get Scaled Image
    func getScaledImage(image : UIImage,width : CGFloat)-> UIImage{
        
        let oldWidth = image.size.width
        let scaleFactor = width / oldWidth
        let newHeight = image.size.height * scaleFactor
        let newWidth = oldWidth * scaleFactor
        UIGraphicsBeginImageContext(CGSize(width : newWidth,height : newHeight))
        image.draw(in: CGRect(x:0, y:0, width : newWidth, height : newHeight))
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return newImage!
    }

}

//Mark: TextField and TextViewDelegates
extension AddNoteViewController:UITextFieldDelegate,UITextViewDelegate{
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        let font = UIFont.systemFont(ofSize: 14)
        let height = heightForView(text: self.noteAddView.noteTextView.text, font: font, width: self.noteAddView.noteTextView.frame.size.width)
        //self.noteAddView.noteTextView.frame.size.height = height
        self.noteAddView.heightConstraintOftitleTextView.constant = height
        updateView()
        return true
    }
    
    func textViewDidBeginEditing(_ textView : UITextView){
        if textView.text == "Note" {
            textView.text = ""
        }
        textView.becomeFirstResponder()
    }
    
    func textViewDidEndEditing(_ textView : UITextView){
        if textView.text == "" {
            textView.text = "Note"
        }
        textView.resignFirstResponder()
    }
    
    func textViewDidChange(_ textView: UITextView) {
        if textView.contentSize.height > textView.frame.size.height {

            let fixedWidth = textView.frame.size.width
            textView.sizeThatFits(CGSize(width: fixedWidth, height: CGFloat.greatestFiniteMagnitude))

            var newFrame = textView.frame
            let newSize = textView.sizeThatFits(CGSize(width: fixedWidth, height: CGFloat.greatestFiniteMagnitude))

            newFrame.size = CGSize(width: max(newSize.width, fixedWidth), height: newSize.height)

            textView.frame = newFrame;

        }
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        let font = UIFont.boldSystemFont(ofSize: 20)
        let height = heightForView(text: self.noteAddView.titleTextView.text, font: font, width: self.noteAddView.titleTextView.frame.size.width)
        //self.noteAddView.titleTextField.frame.size.height = height
        self.noteAddView.heightConstraintOftitleTextView.constant = height
        updateView()
        return true
    }
    
    
    func heightForView(text:String?, font:UIFont, width:CGFloat) -> CGFloat {
        let label:UILabel = UILabel(frame: CGRect(x: 0, y: 0, width: width, height: CGFloat.greatestFiniteMagnitude))
        label.numberOfLines = 0
        label.lineBreakMode = NSLineBreakMode.byWordWrapping
        label.font = font
        label.text = text
        label.sizeToFit()
        if label.frame.height < 40 {
            return 40
        }else{
            return label.frame.height
        }
    }
    
    //Mark: View Update
    func updateView(){
        if let image = self.noteAddView.imageView.image {
            self.noteAddView.heightConstraintOfImageView.constant = image.size.height
        }else{
            self.noteAddView.heightConstraintOfImageView.constant = 0
        }
        let height = self.noteAddView.heightConstraintOfImageView.constant + 24 + self.noteAddView.heightConstraintOftitleTextView.constant + self.noteAddView.heightConstraintOfNoteTextView.constant
        self.noteAddView.contentView.frame.size.height = height
        self.noteAddView.frame.size.height = height
    }
}

