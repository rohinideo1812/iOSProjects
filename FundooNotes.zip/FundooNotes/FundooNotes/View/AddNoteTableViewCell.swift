//
//  AddNoteTableViewCell.swift
//  FundooNotes
//
//  Created by BridgeLabz on 18/05/18.
//  Copyright © 2018 BridgeLabz. All rights reserved.
//

import UIKit

class AddNoteTableViewCell: UITableViewCell {

    //IBOutlet
    @IBOutlet weak var noteTextField: UITextField!
    @IBOutlet weak var titleTextField: UITextField!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
